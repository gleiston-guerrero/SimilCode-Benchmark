#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validar_bigo.py
===============
Ejecuta la validacion del componente de estimacion Big O contra la API oficial
de Anthropic (modelo integrado en produccion), sobre el corpus de algoritmos
canonicos y/o el conjunto adversarial. Produce un CSV de predicciones apto para
evaluar_bigo.py.

Sin dependencias externas (solo biblioteca estandar).

Uso (PowerShell):
  $env:ANTHROPIC_API_KEY = "sk-ant-..."
  python validar_bigo.py --corpus corpus --prompt bigo_prompt.txt --out predicciones_api.csv
  python evaluar_bigo.py --pred predicciones_api.csv --truth ground_truth.csv --out resultados_bigo.csv
"""
import argparse
import csv
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

PLACEHOLDER = "[CÓDIGO_AQUÍ]"
CLASSES = ["O(1)", "O(log n)", "O(n)", "O(n log n)", "O(n^2)", "O(n^3)", "O(2^n)"]


def http_post(url, payload, headers, timeout):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace")), time.time() - t0


def call_anthropic(prompt, model, key, timeout):
    url = "https://api.anthropic.com/v1/messages"
    headers = {"Content-Type": "application/json", "x-api-key": key,
               "anthropic-version": "2023-06-01"}
    payload = {"model": model, "max_tokens": 2048,
               "messages": [{"role": "user", "content": prompt}]}
    obj, latency = http_post(url, payload, headers, timeout)
    text = "".join(b.get("text", "") for b in obj.get("content", [])
                   if b.get("type") == "text")
    return text, latency, str(obj.get("model") or model)


def normalize(raw):
    """Lleva la respuesta a una de las siete clases canonicas."""
    s = " ".join(str(raw).strip().split()).replace("Θ", "O").replace("θ", "O")
    s = s.replace("**", "^").replace("O(2^N)", "O(2^n)")
    s = re.sub(r"\s*\^\s*", "^", s)
    s = re.sub(r"O\s*\(", "O(", s)
    low = s.lower().replace(" ", "")
    table = {
        "o(1)": "O(1)", "o(logn)": "O(log n)", "o(log2n)": "O(log n)",
        "o(n)": "O(n)", "o(nlogn)": "O(n log n)", "o(nlog2n)": "O(n log n)",
        "o(n^2)": "O(n^2)", "o(n2)": "O(n^2)",
        "o(n^3)": "O(n^3)", "o(n3)": "O(n^3)",
        "o(2^n)": "O(2^n)", "o(2n)": "O(2^n)",
    }
    return table.get(low, s)


def parse(text):
    t = re.search(r"COMPLEJIDAD\s+TEMPORAL[^:]*:\s*\[?\s*([^\]\n]+)", text, re.I)
    s = re.search(r"COMPLEJIDAD\s+ESPACIAL[^:]*:\s*\[?\s*([^\]\n]+)", text, re.I)
    j = re.search(r"COMPLEJIDAD\s+TEMPORAL.*?Justificaci[oó]n\s*:?\s*(.+?)(?:\n\s*\n|COMPLEJIDAD|$)",
                  text, re.I | re.S)
    return (normalize(t.group(1)) if t else "",
            normalize(s.group(1)) if s else "",
            " ".join(j.group(1).split())[:400] if j else "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="corpus",
                    help="Carpeta con subcarpetas java/ y csharp/.")
    ap.add_argument("--prompt", default="bigo_prompt.txt")
    ap.add_argument("--out", default="predicciones_api.csv")
    ap.add_argument("--model", default="claude-opus-5")
    ap.add_argument("--replicas", type=int, default=1)
    ap.add_argument("--sleep", type=float, default=0.8)
    ap.add_argument("--timeout", type=float, default=120.0)
    args = ap.parse_args()

    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        sys.exit("Falta la variable de entorno ANTHROPIC_API_KEY.")

    with open(args.prompt, "r", encoding="utf-8") as fh:
        template = fh.read()

    files = []
    for sub, ext in (("java", ".java"), ("csharp", ".cs")):
        d = os.path.join(args.corpus, sub)
        if os.path.isdir(d):
            for name in sorted(os.listdir(d)):
                if name.endswith(ext):
                    files.append((name, os.path.join(d, name)))
    if not files:
        sys.exit("No se encontraron archivos de codigo en " + args.corpus)

    cols = ["filename", "replica", "model_snapshot", "latency_s",
            "pred_time", "pred_space", "justification", "error"]
    total = len(files) * args.replicas
    i = 0
    with open(args.out, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for name, path in files:
            with open(path, "r", encoding="utf-8", errors="replace") as cf:
                code = cf.read()
            prompt = (template.replace(PLACEHOLDER, code)
                      if PLACEHOLDER in template
                      else template.rstrip() + "\n\nCODIGO:\n" + code + "\n")
            for rep in range(1, args.replicas + 1):
                i += 1
                row = {k: "" for k in cols}
                row.update({"filename": name, "replica": rep})
                try:
                    text, lat, snap = call_anthropic(prompt, args.model, key, args.timeout)
                    pt, ps, just = parse(text)
                    row.update({"model_snapshot": snap, "latency_s": round(lat, 3),
                                "pred_time": pt, "pred_space": ps,
                                "justification": just})
                    state = "OK" if pt in CLASSES else f"OK(revisar: {pt})"
                except urllib.error.HTTPError as e:
                    body = ""
                    try:
                        body = e.read().decode("utf-8", errors="replace")
                    except Exception:  # noqa: BLE001
                        pass
                    row["error"] = f"HTTP {e.code}: {body[:200]}"
                    state = "ERROR"
                except Exception as e:  # noqa: BLE001
                    row["error"] = str(e)[:200]
                    state = "ERROR"
                w.writerow(row)
                fh.flush()
                print(f"[{i}/{total}] {name} rep {rep} -> {state}", flush=True)
                if args.sleep > 0:
                    time.sleep(args.sleep)
    print("\nListo. Predicciones en:", args.out)


if __name__ == "__main__":
    main()
